package id.my.hilmiat.sping_h2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpingH2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpingH2Application.class, args);
	}

}
